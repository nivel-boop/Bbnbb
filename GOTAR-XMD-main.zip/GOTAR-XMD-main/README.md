
```
DONT FORGET TO FORK 🍴 & STAR 🌟 REPO😇
```
---

> **CURRENT BOT VERSION ➜ `1.0.0 ⚡`**
---





  <p align="center">
<a href="https://github.com/mrfrank-ofc/followers"><img title="Followers" src="https://img.shields.io/github/followers/gotartech?color=blue&style=flat-square"></a>
<a href="https://github.com/NIVELtech/NIVEL-XMD/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/niveltech/NIVEL-XMD?color=blue&style=flat-square"></a>
<a href="https://github.com/niveltech/NIVEL-XMD/network/members"><img title="Forks" src="https://img.shields.io/github/forks/niveltech/NIVEL-XMD?color=blue&style=flat-square"></a>
<a href="https://github.com/niveltech/NIVEL-XMD/"><img title="Size" src="https://img.shields.io/github/repo-size/NIVEL-XMD/NIVEL-XMD?style=flat-square&color=green"></a>
<a href="https://github.com/niveltech/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a>&nbsp;&nbsp;
</p>

<p align="center">
  <a href="https://git.io/typing-svg">
    <img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=80&pause=1000&color=00FF00&center=true&vCenter=true&width=1000&height=200&lines=NIVEL-XMD;VERSION+2025;BY+NIVEL+TECH" alt="Typing SVG" />
  </a>
</p>
  
--- 

<a><img src='https://files.catbox.moe/q0t3l2.jpg'/></a>



***




### 1. 𐃁FORK THIS REPOSITORY𐃁

`FORK 🍴 AND STAR ⭐ IF YOU LIKE THIS BOT`

  <a href="https://github.com/nivel/NIVEL-XMD/fork"><img title="NIVEL-XMD" src="https://img.shields.io/badge/FORK-NIVEL%20XMD-BOTh?color=indigo&style=for-the-badge&logo=stackshare"></a>
  
### 2. 𐃁GET SESSION ID𐃁 

`IF YOU DON'T HAVE YOUR SESSION_ID SO U CAN GET IT CLICK ON SESSION_ID BUTTON AND PASTE YOUR NUMBER With COUNTRY CODE EXAMPLE:1855xxxxxx THEN YOU CAN GET YOUR SESSION_ID ✠`


> **1. PAIR CODE SESSION ID**

<a href='https://nivel-xmd-session.onrender.com/' target="_blank">
  <img alt='Pairing Code' src='https://img.shields.io/badge/Get%20Pairing%20Code-orange?style=for-the-badge&logo=opencv&logoColor=black'/>
</a>
<br> 

> **2. PAIR CODE SESSION ID**

<a href='https://nivel-xmd-session.onrender.com/' target="_blank">
  <img alt='Pairing Code' src='https://img.shields.io/badge/Get%20Pairing%20Code-darkpink?style=for-the-badge&logo=opencv&logoColor=black'/>
</a>
<br> 



---

### <h2 align="">𐃁NIVEL-XMD DEPLOYMENT OPTIONS𐃁</h2>

---

### <h4 align="">1. HEROKU</h4>
<p style="text-align: center; font-size: 1.2em;">


[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https://github.com/niveltech/NIVEL-XMD)
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

### <h4 align="">3. KOYEB</h4>
<p style="text-align: center; font-size: 1.2em;">

<p align="">
<a href='https://app.koyeb.com/services/deploy?type=git&repository=niveltech/NIVEL-XMD&ports=3000&env[PREFIX]=.&env[SESSION_ID]=&env[ALWAYS_ONLINE]=false&env[MODE]=public&env[AUTO_STATUS_MSG]=Seen%20status%20by%20NIVEL-XMD&env[AUTO_STATUS_REPLY]=false&env[AUTO_STATUS_SEEN]=true&env[AUTO_TYPING]=false&env[ANTI_LINK]=true&env[AUTO_REACT]=false&env[READ_MESSAGE]=false' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-koyeb ‎ deploy-FF009D?style=for-the-badge&logo=koyeb&logoColor=white'/< width=150 height=28/p></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

### <h4 align="">2. TALKDROVE FREE</h4>
<p style="text-align: center; font-size: 1.2em;">
  
<p align="">
<a href='https://talkdrove.com/share-bot/' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-TalkDrove ‎Deploy-6971FF?style=for-the-badge&logo=Github&logoColor=white'/< width=150 height=28/p></a>
  <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

### <h4 align="">4. RAILWAY</h4>
<p style="text-align: center; font-size: 1.2em;">

<p align="">
<a href='https://railway.app/new' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-railway deploy-FF8700?style=for-the-badge&logo=railway&logoColor=white'/< width=150 height=28/p></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

### <h4 align="">5. RENDER</h4>
<p style="text-align: center; font-size: 1.2em;">
  
<p align="">
<a href='https://dashboard.render.com/web/new' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Render deploy-black?style=for-the-badge&logo=render&logoColot=white'/< width=150 height=28/p></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

### <h4 align="">6. HUGGING FACE</h4>
<p style="text-align: center; font-size: 1.2em;">
  
<p align="">
<a href='https://app.netlify.com/' target="_blank"><img alt='Netlify' src='https://img.shields.io/badge/-Netlify Deploy-CC00FF?style=for-the-badge&logo=huggingface&logoColor=white'/< width=150 height=28/p></a> </a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<details>
  
<b><strong><summary align="" style="color: Yello;">SIMPLIEST METHOD 2</summary></strong></b>
<p style="text-align: center; font-size: 1.2em;">
 

## <h3 align=""> HOW TO DEPLOY ON HUGGING FACE</h3>
<h6 align-"center">
*❄️ Deploy NIVEL-XMD On Hugging Face For Free !*

`Specs :`
- v2 CPU
- 16GB RAM

> `Steps to deploy`

`Step 1`
1. Go to hugginface.co/join and create an account and verify your email too.

`Step 2`
1. Go to https://huggingface.co/spaces/nivel/NIVEL-XMD

2. Tap on *three dots* _(as shown in image)_

3. Tap on *duplicate space* _(as shown in image)_

`Step 3`
1. Fill your details, e.g., Session ID, Bot Name, owner number etc...

2. Tap on *duplicate space shown below*

```After that wait 10 seconds & your have deployed it successfuly  for free 24/7```

> CREDITS 🎐

*ᴘᴏᴡᴇʀᴇᴅ ʙʏ ᴅʏʙʏ ᴛᴇᴄʜ*</h6>

</details>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


### <h4 align="">7. REPLIT</h4>
<p style="text-align: center; font-size: 1.2em;">

<p align="">
<a href='https://replit.com/~' target="_blank"><img alt='Replit' src='https://img.shields.io/badge/-Replit Deploy-1976D2?style=for-the-badge&logo=replit&logoColor=white'/< width=150 height=28/p></a> </a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


## WORKFLOWS

```
name: Node.js CI

on:
  push:
    branches:
      - main
  pull_request:
    branches:
      - main
  schedule:
    - cron: '0 */6 * * *'  

jobs:
  build:

    runs-on: ubuntu-latest

    strategy:
      matrix:
        node-version: [20.x]

    steps:
    - name: Checkout repository
      uses: actions/checkout@v3

    - name: Set up Node.js
      uses: actions/setup-node@v3
      with:
        node-version: ${{ matrix.node-version }}

    - name: Install dependencies
      run: npm install

    - name: Install FFmpeg
      run: sudo apt-get install -y ffmpeg

    - name: Start application with timeout
      run: |
        timeout 21590s npm start  # Limite l'exécution à 6h 59m 59s

    - name: Save state (Optional)
      run: |
        ./save_state.sh
```



## 👑 PROJECT OWNER 
HII DEARS FRIENDS IF YOU WANT ANY HELP SO YOU CAN CONTACT↘︎ WITH ME WIA WHATSAPP ITS ME NIVEL TECH࿐➺

<p align="">
<a href='https://wa.me/0735230716?text=*ʜɪɪ+NIVEL+ᴛᴇᴄʜ+ɪ+ɴᴇᴇᴅ+ʜᴇʟᴘ!.+ɪ+ᴍᴇssᴀɢᴇᴅ+ʏᴏᴜ+ғʀᴏᴍ+NIVEL+𝗫𝗠𝗗+ʀᴇᴘᴏ!!*' target="_blank"><img alt='Replit' src='https://img.shields.io/badge/ Whatsapp -25D366?style=for-the-badge&logo=whatsapp&logoColor=white'/< width=150 height=28/p></a> </a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


## 🪀 WHATSAPP CHANNEL 
STAY CONNECTED WITH THE LATEST UPDATES AND COMMUNITY BY JOINING OUR OFFICIAL WHATSAPP GROUP AND CHANNEL. YOU CAN ALSO CONTACT THE OWNER DIRECTLY.

[![WhatsApp Channel](https://img.shields.io/badge/JOIN-WHATSAAP%20CHANNEL-25D366?style=for-the-badge&logo=whatsapp)](https://whatsapp.com/channel/0029VbAOpMmAInPoTescPr0y)

## 🪀 WHATSAPP GROUP
JOINING OUR OFFICIAL WHATSAPP GROUP AND CHANNEL. YOU CAN ALSO CONTACT THE OWNER DIRECTLY.


 


***

## <h2 align="left">⚠️ REMINDER </h2>
<p style="text-align: center; font-size: 1.2em;">

- **DISCLAIMER:** THIS BOT IS NOT AFFILIATED WITH `WhatsApp Inc.`. USE IT AT YOUR OWN RISK.
- MISUSING THE BOT MAY RESULT IN YOUR `WhatsApp` ACCOUNT BEING BANNED. NOTE THAT YOU CAN ONLY UNBAN YOUR ACCOUNT ONCE.
- I AM NOT RESPONSIBLE FOR ANY BANS OR MISUSE OF THE BOT. PLEASE KEEP THIS WARNING IN MIND BEFORE PROCEEDING.

---

<h2 align="left">ℹ️ NOTICE</h2>
<p style="text-align: center; font-size: 1.2em;">
  NOT FOR SALE - IF ANY PLUGIN'S CODE IS OBFUSCATED, YOU DO NOT HAVE PERMISSION TO EDIT IT IN ANY FORM. PLEASE REMEMBER TO GIVE CREDIT IF YOU ARE USING OR RE-UPLOADING MY PLUGINS/FILES. WISHING YOU A WONDERFUL DAY AHEAD!</p>
  
---

 <br>
<h2 align="center"> ⚠️ DISCLAIMER ⚠️
 </h2>
 
 ---

<h3 align="center"> DON'T COPY WITHOUT PERMISSION 
</h3>

<br>

```
THANK YOU DybyTech,  & YOU SUPPORTERS
```
-----
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

------
